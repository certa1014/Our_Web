from django.contrib import admin
from introduce.models import guestbook

admin.site.register(guestbook)
