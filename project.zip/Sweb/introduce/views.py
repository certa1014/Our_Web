from django.http import HttpResponseRedirect
from django.urls import reverse
from django.shortcuts import render
from introduce.models import guestbook

#메인 페이지로 이동
def movetomain(request):
    return render(request, 'introduce/index.html')

#프로젝트a 소개로 이동
def movetoa(request):
    return render(request, 'introduce/projecta_Our Web.html')

#프로젝트b 소개로 이동
def movetob(request):
    return render(request, 'introduce/projectb_Wired keyboard.html')

#프로젝트c 소개로 이동
def movetoc(request):
    return render(request, 'introduce/projectc_Hack Tool.html')

#방명록 리스트로 이동
def movetoguestbook(request):
    qs = guestbook.objects.all()
    context = {'guestbook_list': qs}
    return render(request, 'introduce/guestbook.html', context)

#방명록 등록페이지로 이동
def guestbookreg(request):
    return render(request, 'introduce/guestbookreg.html')

#입력한 방명록을 DB에 등록
def guestbookregCon(request):
    name = request.POST['name']
    write = request.POST['write']
    
    qs = guestbook(g_name=name, g_write=write)
    qs.save()
    
    return HttpResponseRedirect(reverse('introduce:guestbook'))

def guestbookdet(request, name):
    qs = guestbook.objects.get(g_name = name)
    context = {'guestbook_info': qs}
    return render(request, 'introduce/guestbookdet.html', context)
    
def csstest(request):
    return render(request, 'introduce/index.html')