from django.apps import AppConfig


class IntroduceConfig(AppConfig):
    name = 'introduce'
