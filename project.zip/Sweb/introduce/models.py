from django.db import models

class guestbook(models.Model):
    g_name = models.CharField(max_length=100)
    g_write = models.CharField(max_length=2000)
    
    def __str__(self):
        return self.g_name